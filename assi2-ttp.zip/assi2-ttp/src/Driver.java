

import java.io.*;
import ttp.Optimisation.Optimisation;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import ttp.Optimisation.OptimisationofDynamicItems;
import ttp.TTPInstance;
import ttp.TTPSolution;
import ttp.Utils.DeepCopy;
import ttp.Utils.Utils;

/**
 *
 * @author wagner
 */
public class Driver {
    
    /* The current sequence of parameters is
     * args[0]  folder with TTP files
     * args[1]  pattern to identify the TTP problems that should be solved
     * args[2]  optimisation approach chosen 1,2,12,22
     * args[3]  stopping criterion: number of evaluations without improvement
     * args[4]  stopping criterion: time in milliseconds (e.g., 60000 equals 1 minute)
     */
    public static void main(String[] args) {
       
        if (args.length==0) 
 //           args = new String[]{"instances", "a280_n279_bounded-strongly-corr_01.ttp", // to do all 10 instances (several files match the pattern)
//            args = new String[]{"instances", "a280_n1395_uncorr-similar-weights_05.ttp", // to do just this 1 instance
//            args = new String[]{"instances", "fnl4461_n4460_bounded-strongly-corr_01.ttp", // to do just this 1 instance
//            args = new String[]{"instances", "pla33810_n169045_uncorr-similar-weights_05.ttp", // to do just this 1 instance

//            args = new String[]{"instances", "pla33810_n33809_bounded-strongly-corr_01.ttp", // to do all 10 instances (several files match the pattern)
//            args = new String[]{"instances", "fnl4461_n44600_uncorr_10.ttp", // to do just this 1 instance
//            args = new String[]{"instances", "fnl4461_n22300_uncorr-similar-weights_05.ttp", // to do just this 1 instance
//            args = new String[]{"instances", "pla33810_n338090_uncorr_10.ttp", // to do just this 1 instance
                args = new String[]{"instances", "pla33810_", // to do just this 1 instance

                            "7", "100000", "6000000"};
//        ttp.Optimisation.Optimisation.doAllLinkernTours();
//        runSomeTests();
        int run = 1;
        for(int i = 0; i < run; i++) {
            doBatch(args);
        }
    }
    
    // note: doBatch can process several files sequentially
    public static void doBatch(String[] args) {
//        String[] args = new String[]{"instances/","a2"};                      // first argument: folder with TTP and TSP files, second argument: partial filename of the instances to be solved   
//        System.out.println("parameters: "+Arrays.toString(args));
        File[] files = ttp.Utils.Utils.getFileList(args);
        
        int algorithm = Integer.parseInt(args[2]);
        int durationWithoutImprovement = Integer.parseInt(args[3]);
        int maxRuntime = Integer.parseInt(args[4]);
        //int exercise = Integer.parseInt(args[5]);
        
//        System.out.println("files.length="+files.length+" algorithm="+algorithm+" durationWithoutImprovement="+durationWithoutImprovement);
//        System.out.println("wend wendUsed fp ftraw ft ob computationTime");
        
        for (File f:files) {
            // read the TSP instance
            TTPInstance instance = new TTPInstance(f);
            //System.out.println(instance.items.length);
            long startTime = System.currentTimeMillis();
            String resultTitle = instance.file.getName() + ".NameOfTheAlgorithm." + startTime;
            
            // generate a Linkern tour (or read it if it already exists)
            int[] tour = Optimisation.linkernTour(instance);


            System.out.println(f.getName()+": ");
            
            // do the optimisation
            TTPSolution solution = null;

            if(algorithm <5) {
                solution = Optimisation.hillClimber(instance, tour, algorithm,
                        durationWithoutImprovement, maxRuntime);
            }

            if(algorithm == 5 || algorithm == 6) {
                solution = OptimisationofDynamicItems.hillClimber(instance, tour, algorithm,
                        durationWithoutImprovement, maxRuntime);
            }
            if(algorithm == 7) {
                solution = OptimisationofDynamicItems.greedyHillClimber(instance, tour,
                        durationWithoutImprovement, maxRuntime);
            }
            
            // print to file
//            solution.writeResult(resultTitle);
            
            // print to screen
            solution.println();
            
            
//            solution.printFull();
        }
    }
    

    
}
