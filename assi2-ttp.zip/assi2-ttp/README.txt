The code of exercise 2 is generally based on the packing code.  

Driver.java is modified for exercise 2 but the arguments are same.

Class OptimisationofDynamicItems is the main class of exercise 2 of Dynamic items.
The dynamic benchmarks would be created at the first run.  Have to choose benchmark 1 or 2 manually in line 15 of class OptimisationofDynamicItems.